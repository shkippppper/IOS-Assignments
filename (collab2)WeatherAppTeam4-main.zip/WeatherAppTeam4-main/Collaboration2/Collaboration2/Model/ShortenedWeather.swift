//
//  ShortenedWeather.swift
//  Collaboration2
//
//  Created by nuca on 12.06.24.
//

import Foundation
